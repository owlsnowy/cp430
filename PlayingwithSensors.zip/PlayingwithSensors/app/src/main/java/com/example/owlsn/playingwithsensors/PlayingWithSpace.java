package com.example.owlsn.playingwithsensors;

import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class PlayingWithSpace extends AppCompatActivity implements SensorEventListener, LocationListener {

    public SensorManager senseMngr;
    public Sensor sense;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playing_with_space);
        ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 101);

        senseMngr = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        sense = senseMngr.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        senseMngr.registerListener(this, sense, SensorManager.SENSOR_DELAY_NORMAL);
    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    public void onLocationChanged(Location location) {

    }

    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    public void onProviderEnabled(String provider) {

    }

    public void onProviderDisabled(String provider) {

    }

    public void start(View view) {

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},1);
        } else {
            LocationManager locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);


            LocationListener locationListener = new LocationListener() {

                @Override
                public void onLocationChanged(Location location) {
                    updateGPS(location);
                }

                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {
                }

                @Override
                public void onProviderEnabled(String provider) {
                }

                @Override
                public void onProviderDisabled(String provider) {
                }
            };
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        Sensor mySensor = event.sensor;

        if (mySensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            double X = event.values[0];
            double Y = event.values[1];
            double Z = event.values[2];
            updateA(X, Y, Z);
        }
    }


    public void updateA(double x, double y, double z) {
        TextView x2 = findViewById(R.id.lblx);
        TextView y2 = findViewById(R.id.lbly);
        TextView z2 = findViewById(R.id.lblz);

        x2.setText("X: " + String.valueOf(x));
        y2.setText("Y: " + String.valueOf(y));
        z2.setText("Z: " + String.valueOf(z));
    }


    public void updateGPS(Location location) {
        TextView gpsLat = findViewById(R.id.lbllat);
        TextView gpsLong = findViewById(R.id.lbllong);
        gpsLat.setText("Latitude: " + Double.toString(location.getLatitude()));
        gpsLong.setText("Longitude: " + Double.toString(location.getLongitude()));

    }


}