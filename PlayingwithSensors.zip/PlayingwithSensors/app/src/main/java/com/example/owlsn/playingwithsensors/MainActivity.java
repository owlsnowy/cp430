package com.example.owlsn.playingwithsensors;

import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void listSensors(View view){

        SensorManager mngr = (SensorManager) getSystemService(SENSOR_SERVICE);
        List<Sensor> sensors = mngr.getSensorList(Sensor.TYPE_ALL);
        EditText multi = findViewById(R.id.txtMulti);
        for (Sensor sensor : sensors) {
            multi.append(sensor.getName() + "\n");
        }


        EditText single = findViewById(R.id.txtSingle);
        single.setText("Number of sensors: " + sensors.size());
    }
    public void playingwithspacetransfer(View view){
        Intent intent = new Intent(this,PlayingWithSpace.class);
        startActivity(intent);
    }
}
