package com.example.owlsn.mobileprogramming;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void Carpe(View view){
        TextView output = (TextView)findViewById(R.id.Hold);
        output.setText("carpe diem");
    }
    public void Reset(View view){
        TextView output = (TextView)findViewById(R.id.Hold);
        output.setText(R.string.Name);
    }
    public void Radio(View view){
        TextView output = (TextView)findViewById(R.id.textDetails);
        output.setText("The Radio button is used for selecting an option usually when only one option is allowed per choice");
    }
    public void Check(View view){
        TextView output = (TextView)findViewById(R.id.textDetails);
        output.setText("The Check box is used for selecting an option, usually when more than one option is allowed per choice");
    }
}
